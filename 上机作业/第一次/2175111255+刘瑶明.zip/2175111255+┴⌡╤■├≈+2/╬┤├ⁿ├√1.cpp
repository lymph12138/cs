#include <stdio.h>
#define pi 3.1415926
int main()
 {
 	int r=5;
 	double l,s;
 	l=2*pi*r;
 	s=pi*r*r;
 	printf("l=%lf\n",l);
 	printf("s=%lf\n",s);
 	return 0;
 }
